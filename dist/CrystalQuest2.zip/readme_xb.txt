Unzip this file into your Classic99\DSK1 folder.
To start it, select the EXTENDED BASIC cartridge.
Follow the menus to start Extended BASIC.
Type: OLD DSK1.CQUEST2
Type: RUN

Use joystick 1 (Arrow keys and TAB)
Hold fire and press up or down in palaces to use
elevators.
Press fire on map to bring up load/save options.

Disabling CPU throttle in options will make most
XB games respond better. If you get repeating
characters when typing, turn the throttle on again.
